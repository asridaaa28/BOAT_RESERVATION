package com.example.sga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgaApplicationTests {

	@Test
	void contextLoads() {
	}

}
